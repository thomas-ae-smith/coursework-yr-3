
// Abstract class, hence function definitions do nothing.

// // Include header file for function declarations
// #include "AbstractObject.h"

// #include <stdio.h>

// // void abstractObject::update(double t) {};
// void abstractObject::render() {printf("Error: trying to render an abstract object.");};
// void abstractObject::debug() {};
// abstractObject::~abstractObject() {};
