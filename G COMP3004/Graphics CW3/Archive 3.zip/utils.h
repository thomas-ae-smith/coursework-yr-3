// Provided code
#ifndef _UTILS_H_
#define _UTILS_H_


/* A simple function that will read a file into an allocated char pointer buffer */
const char* filetobuf(const char *file);

#endif /* #ifndef _UTILS_H_ */
