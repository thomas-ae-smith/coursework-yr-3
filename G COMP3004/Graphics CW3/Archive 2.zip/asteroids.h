// Not yet implemented
#ifndef _ASTEROIDS_H_
#define _ASTEROIDS_H_ value

#include "GameObject.h"

class asteroids : public gameObject
{
public:
	asteroids(abstractObject* parent) : gameObject(parent) {};
	~asteroids();

	/* data */
};

#endif /* #ifndef _ASTEROIDS_H_ */
