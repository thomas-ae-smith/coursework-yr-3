/*
Abstract class, hence function definitions do nothing.
*/
// Include header file for function declarations
#include "AbstractObject.h"

void abstractObject::update(double t) {};
void abstractObject::render() {};
void abstractObject::debug() {};
abstractObject::~abstractObject() {};
