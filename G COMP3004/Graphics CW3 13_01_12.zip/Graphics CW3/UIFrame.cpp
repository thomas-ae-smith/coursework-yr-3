/* abstract class; parent to Game and Help*/
#include "UIFrame.h"

